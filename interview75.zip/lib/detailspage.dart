import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class DetailsPage extends StatefulWidget {
  final String imdbId;

   const DetailsPage({super.key,
     required this.imdbId,

  });

  factory DetailsPage.fromJson(Map<String, dynamic> jsonDet)=> DetailsPage(
    imdbId: jsonDet["imdbID"],

  );

  @override
  State<DetailsPage> createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  var details = "";

  // @override
  void fetchDetails() async {
    final response = await http.get(
      Uri.parse("https://www.omdbapi.com/?apikey=39a36280&i=tt0371746"),
    );

    if (response.statusCode == 200) {
      // The API call was successful, parse the response.
      final jsonData = json.decode(response.body);
      setState(() {
        details = jsonData;
      });
    } else {
      // The API call failed.
      showToast("Failed to load data");
    }
  }

  void showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: details.isEmpty
    ? Center(
    child: ElevatedButton(
      onPressed: fetchDetails,
      child: const Text('Load Photos'),
    ),
    ) :
    Container(
      child: Column(
        children: [
          Text(details.title),
        ],
      ),
    )
    );
  }
}
