package com.example.interview75

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
